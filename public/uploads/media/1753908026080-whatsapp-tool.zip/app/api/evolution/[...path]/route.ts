import { type NextRequest, NextResponse } from "next/server"

// Certifique-se de que estas variáveis de ambiente estão definidas no seu projeto Vercel
const EVOLUTION_API_BASE_URL = process.env.EVOLUTION_API_BASE_URL
const EVOLUTION_API_GLOBAL_API_KEY = process.env.EVOLUTION_API_GLOBAL_API_KEY

if (!EVOLUTION_API_BASE_URL || !EVOLUTION_API_GLOBAL_API_KEY) {
  console.error("Variáveis de ambiente EVOLUTION_API_BASE_URL ou EVOLUTION_API_GLOBAL_API_KEY não estão definidas.")
  // Em um ambiente de produção, você pode querer lançar um erro ou lidar com isso de forma mais robusta.
}

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const url = new URL(request.url)
  const queryParams = url.searchParams.toString()

  // Determine which API key to use based on the path
  const apiKey = request.headers.get("apikey") || EVOLUTION_API_GLOBAL_API_KEY

  const evolutionApiUrl = `${EVOLUTION_API_BASE_URL}/${path}${queryParams ? `?${queryParams}` : ""}`

  try {
    const response = await fetch(evolutionApiUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        apikey: apiKey,
      },
    })

    const data = await response.json()
    return NextResponse.json(data, { status: response.status })
  } catch (error: any) {
    console.error("Erro ao proxy GET request:", error)
    return NextResponse.json({ message: "Erro interno do servidor", error: error.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const body = await request.json()

  // Determine which API key to use based on the path
  const apiKey = request.headers.get("apikey") || EVOLUTION_API_GLOBAL_API_KEY

  const evolutionApiUrl = `${EVOLUTION_API_BASE_URL}/${path}`

  try {
    const response = await fetch(evolutionApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: apiKey,
      },
      body: JSON.stringify(body),
    })

    const data = await response.json()
    return NextResponse.json(data, { status: response.status })
  } catch (error: any) {
    console.error("Erro ao proxy POST request:", error)
    return NextResponse.json({ message: "Erro interno do servidor", error: error.message }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const url = new URL(request.url)
  const queryParams = url.searchParams.toString()

  // Determine which API key to use based on the path
  const apiKey = request.headers.get("apikey") || EVOLUTION_API_GLOBAL_API_KEY

  const evolutionApiUrl = `${EVOLUTION_API_BASE_URL}/${path}${queryParams ? `?${queryParams}` : ""}`

  try {
    const response = await fetch(evolutionApiUrl, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        apikey: apiKey,
      },
    })

    const data = await response.json()
    return NextResponse.json(data, { status: response.status })
  } catch (error: any) {
    console.error("Erro ao proxy DELETE request:", error)
    return NextResponse.json({ message: "Erro interno do servidor", error: error.message }, { status: 500 })
  }
}

// Adicione outros métodos HTTP (PUT, PATCH, etc.) conforme necessário pela API da Evolution
