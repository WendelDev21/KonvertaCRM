"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { ThemeToggle } from "@/components/theme-toggle"
import { CreateInstanceDialog } from "@/components/create-instance-dialog"
import { InstanceCard } from "@/components/instance-card"
import { PlusCircle, RefreshCw, Loader2 } from "lucide-react"

interface Instance {
  name: string
  apiKey: string
  status: "connected" | "disconnected" | "qr_code" | "loading"
  qrCode?: string | null
}

export default function HomePage() {
  const [instances, setInstances] = useState<Instance[]>([])
  const [isCreateInstanceDialogOpen, setIsCreateInstanceDialogOpen] = useState(false)
  const [loadingInstances, setLoadingInstances] = useState(true)
  const { toast } = useToast()

  const fetchInstances = useCallback(async () => {
    setLoadingInstances(true)
    try {
      const response = await fetch("/api/evolution/instance/fetchInstances", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          // Global API key is used for fetching all instances
          apikey: process.env.NEXT_PUBLIC_EVOLUTION_API_GLOBAL_API_KEY,
        },
      })
      const data = await response.json()

      if (response.ok) {
        const fetchedInstances: Instance[] = await Promise.all(
          data.map(async (inst: any) => {
            let status: Instance["status"] = "disconnected"
            let qrCode: string | null = null

            // Check connection status for each instance
            try {
              const statusResponse = await fetch(`/api/evolution/instance/connectionState/${inst.instanceName}`, {
                method: "GET",
                headers: {
                  apikey: inst.apikey, // Use instance-specific API key
                },
              })
              const statusData = await statusResponse.json()
              if (statusResponse.ok && statusData.state === "connected") {
                status = "connected"
              } else if (statusResponse.ok && statusData.state === "qrcode") {
                status = "qr_code"
                // Fetch QR code if status is qrcode
                const qrResponse = await fetch(`/api/evolution/instance/connect/${inst.instanceName}`, {
                  method: "GET",
                  headers: {
                    apikey: inst.apikey,
                  },
                })
                const qrData = await qrResponse.json()
                if (qrResponse.ok && qrData.base64) {
                  qrCode = qrData.base64
                }
              }
            } catch (statusError) {
              console.error(`Error fetching status for ${inst.instanceName}:`, statusError)
              status = "disconnected" // Default to disconnected on error
            }

            return {
              name: inst.instanceName,
              apiKey: inst.apikey,
              status: status,
              qrCode: qrCode,
            }
          }),
        )
        setInstances(fetchedInstances)
        toast({
          title: "Instâncias Carregadas",
          description: `Foram encontradas ${fetchedInstances.length} instâncias.`,
        })
      } else {
        throw new Error(data.message || "Erro ao buscar instâncias.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Carregar Instâncias",
        description: error.message || "Ocorreu um erro inesperado ao buscar instâncias.",
        variant: "destructive",
      })
      setInstances([])
    } finally {
      setLoadingInstances(false)
    }
  }, [toast])

  useEffect(() => {
    fetchInstances()
  }, [fetchInstances])

  const handleInstanceUpdate = (instanceName: string, newStatus: Partial<Instance>) => {
    setInstances((prevInstances) =>
      prevInstances.map((inst) => (inst.name === instanceName ? { ...inst, ...newStatus } : inst)),
    )
  }

  const handleInstanceDelete = (instanceName: string) => {
    setInstances((prevInstances) => prevInstances.filter((inst) => inst.name !== instanceName))
  }

  const handleCreateInstanceSuccess = (newInstance: Instance) => {
    setInstances((prevInstances) => [...prevInstances, newInstance])
    setIsCreateInstanceDialogOpen(false)
  }

  return (
    <div className="flex min-h-screen flex-col items-center p-4 md:p-8">
      <header className="flex w-full max-w-6xl items-center justify-between py-4">
        <h1 className="text-3xl font-bold">WhatsApp Bulk Messenger</h1>
        <ThemeToggle />
      </header>

      <main className="w-full max-w-6xl flex-grow py-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-2xl font-bold">Minhas Instâncias</CardTitle>
            <div className="flex gap-2">
              <Button onClick={fetchInstances} disabled={loadingInstances} variant="outline">
                {loadingInstances ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="mr-2 h-4 w-4" />
                )}
                Atualizar
              </Button>
              <Button onClick={() => setIsCreateInstanceDialogOpen(true)}>
                <PlusCircle className="mr-2 h-4 w-4" />
                Nova Instância
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loadingInstances ? (
              <div className="flex flex-col items-center justify-center h-48">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <p className="mt-4 text-lg text-muted-foreground">Carregando suas instâncias...</p>
              </div>
            ) : instances.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                <p className="text-lg">Nenhuma instância encontrada.</p>
                <p className="text-sm">Clique em "Nova Instância" para começar.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {instances.map((instance) => (
                  <InstanceCard
                    key={instance.name}
                    instance={instance}
                    onUpdate={handleInstanceUpdate}
                    onDelete={handleInstanceDelete}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <CreateInstanceDialog
        isOpen={isCreateInstanceDialogOpen}
        onClose={() => setIsCreateInstanceDialogOpen(false)}
        onCreateSuccess={handleCreateInstanceSuccess}
      />
    </div>
  )
}
