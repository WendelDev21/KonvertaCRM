"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface SendMessageDialogProps {
  isOpen: boolean
  onClose: () => void
  instanceName: string
  instanceApiKey: string
}

export function SendMessageDialog({ isOpen, onClose, instanceName, instanceApiKey }: SendMessageDialogProps) {
  const [recipient, setRecipient] = useState("")
  const [message, setMessage] = useState("")
  const [bulkRecipients, setBulkRecipients] = useState("")
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handleSendMessage = async (isBulk: boolean) => {
    setLoading(true)
    try {
      let numbersToSend: string[] = []
      if (isBulk) {
        numbersToSend = bulkRecipients
          .split(",")
          .map((num) => num.trim())
          .filter((num) => num)
        if (numbersToSend.length === 0) {
          throw new Error("Por favor, insira pelo menos um número para envio em massa.")
        }
      } else {
        if (!recipient) {
          throw new Error("Por favor, insira o número do destinatário.")
        }
        numbersToSend = [recipient.trim()]
      }

      if (!message) {
        throw new Error("Por favor, insira a mensagem a ser enviada.")
      }

      const results = await Promise.all(
        numbersToSend.map(async (number) => {
          const response = await fetch(`/api/evolution/message/sendText/${instanceName}`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: instanceApiKey,
            },
            body: JSON.stringify({ number, text: message }),
          })
          const data = await response.json()
          if (!response.ok) {
            throw new Error(`Erro ao enviar para ${number}: ${data.message || "Erro desconhecido"}`)
          }
          return { number, success: true }
        }),
      )

      const successfulSends = results.filter((r) => r.success).length
      const failedSends = results.filter((r) => !r.success).length

      toast({
        title: "Mensagens Enviadas!",
        description: `Sucesso: ${successfulSends} | Falha: ${failedSends}.`,
      })
      setRecipient("")
      setMessage("")
      setBulkRecipients("")
      onClose()
    } catch (error: any) {
      toast({
        title: "Erro ao Enviar Mensagem",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Enviar Mensagem ({instanceName})</DialogTitle>
          <DialogDescription>Envie mensagens para um ou vários contatos.</DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="individual" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="individual">Individual</TabsTrigger>
            <TabsTrigger value="bulk">Em Massa</TabsTrigger>
          </TabsList>
          <TabsContent value="individual">
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="recipient" className="text-right">
                  Número
                </Label>
                <Input
                  id="recipient"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  placeholder="Ex: 5511987654321"
                  className="col-span-3"
                  disabled={loading}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="message" className="text-right">
                  Mensagem
                </Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Sua mensagem aqui..."
                  className="col-span-3"
                  disabled={loading}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose} disabled={loading}>
                Cancelar
              </Button>
              <Button onClick={() => handleSendMessage(false)} disabled={loading}>
                {loading ? "Enviando..." : "Enviar Mensagem"}
              </Button>
            </DialogFooter>
          </TabsContent>
          <TabsContent value="bulk">
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="bulkRecipients" className="text-right">
                  Números (separados por vírgula)
                </Label>
                <Textarea
                  id="bulkRecipients"
                  value={bulkRecipients}
                  onChange={(e) => setBulkRecipients(e.target.value)}
                  placeholder="Ex: 5511987654321, 5521912345678"
                  className="col-span-3"
                  disabled={loading}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="bulkMessage" className="text-right">
                  Mensagem
                </Label>
                <Textarea
                  id="bulkMessage"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Sua mensagem aqui..."
                  className="col-span-3"
                  disabled={loading}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose} disabled={loading}>
                Cancelar
              </Button>
              <Button onClick={() => handleSendMessage(true)} disabled={loading}>
                {loading ? "Enviando em Massa..." : "Enviar em Massa"}
              </Button>
            </DialogFooter>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
