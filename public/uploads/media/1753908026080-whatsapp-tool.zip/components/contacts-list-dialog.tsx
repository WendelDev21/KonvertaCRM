"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

interface ContactsListDialogProps {
  isOpen: boolean
  onClose: () => void
  instanceName: string
  instanceApiKey: string
}

interface Contact {
  id: string
  name: string
  number: string
}

export function ContactsListDialog({ isOpen, onClose, instanceName, instanceApiKey }: ContactsListDialogProps) {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    if (isOpen) {
      fetchContacts()
    }
  }, [isOpen, instanceName, instanceApiKey])

  const fetchContacts = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/evolution/chat/findContacts/${instanceName}`, {
        method: "POST", // findContacts uses POST
        headers: {
          "Content-Type": "application/json",
          apikey: instanceApiKey,
        },
        body: JSON.stringify({ where: {} }), // Empty where to get all contacts
      })

      const data = await response.json()

      if (response.ok) {
        // Assuming data is an array of contacts directly or nested
        const formattedContacts = data.contacts
          ? data.contacts.map((c: any) => ({
              id: c.id,
              name: c.name || c.pushName || "Nome Desconhecido",
              number: c.id.split("@")[0], // Extract number from JID
            }))
          : data.map((c: any) => ({
              id: c.id,
              name: c.name || c.pushName || "Nome Desconhecido",
              number: c.id.split("@")[0],
            }))
        setContacts(formattedContacts)
        toast({
          title: "Contatos Carregados",
          description: `Foram encontrados ${formattedContacts.length} contatos para a instância "${instanceName}".`,
        })
      } else {
        throw new Error(data.message || "Erro ao buscar contatos.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Carregar Contatos",
        description: error.message || "Ocorreu um erro inesperado ao buscar contatos.",
        variant: "destructive",
      })
      setContacts([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Contatos da Instância ({instanceName})</DialogTitle>
          <DialogDescription>Lista de contatos da sua instância do WhatsApp.</DialogDescription>
        </DialogHeader>
        {loading ? (
          <div className="flex flex-col items-center justify-center flex-grow">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="mt-2 text-sm text-muted-foreground">Carregando contatos...</p>
          </div>
        ) : (
          <>
            {contacts.length === 0 ? (
              <div className="flex flex-col items-center justify-center flex-grow text-muted-foreground">
                <p>Nenhum contato encontrado.</p>
                <p className="text-sm">Certifique-se de que a instância está conectada e possui contatos.</p>
              </div>
            ) : (
              <ScrollArea className="flex-grow pr-4">
                <div className="grid gap-2">
                  {contacts.map((contact) => (
                    <div key={contact.id} className="flex items-center justify-between py-2">
                      <div>
                        <p className="font-medium">{contact.name}</p>
                        <p className="text-sm text-muted-foreground">{contact.number}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </>
        )}
        <div className="flex justify-end pt-4">
          <Button onClick={onClose}>Fechar</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
