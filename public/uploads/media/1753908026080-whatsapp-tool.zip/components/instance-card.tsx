"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"
import { Loader2, CheckCircle2, XCircle, QrCode, Plug, LogOut, Trash2, MessageSquare, Users } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { SendMessageDialog } from "./send-message-dialog"
import { ContactsListDialog } from "./contacts-list-dialog"

interface Instance {
  name: string
  apiKey: string
  status: "connected" | "disconnected" | "qr_code" | "loading"
  qrCode?: string | null
}

interface InstanceCardProps {
  instance: Instance
  onUpdate: (instanceName: string, newStatus: Partial<Instance>) => void
  onDelete: (instanceName: string) => void
}

export function InstanceCard({ instance, onUpdate, onDelete }: InstanceCardProps) {
  const { toast } = useToast()
  const [loadingAction, setLoadingAction] = useState<string | null>(null)
  const [isSendMessageDialogOpen, setIsSendMessageDialogOpen] = useState(false)
  const [isContactsListDialogOpen, setIsContactsListDialogOpen] = useState(false)

  const handleConnect = async () => {
    setLoadingAction("connect")
    try {
      const response = await fetch(`/api/evolution/instance/connect/${instance.name}`, {
        method: "GET",
        headers: {
          apikey: instance.apiKey,
        },
      })
      const data = await response.json()

      if (response.ok) {
        if (data.base64) {
          onUpdate(instance.name, { status: "qr_code", qrCode: data.base64 })
          toast({
            title: "Escaneie o QR Code",
            description: "Por favor, escaneie o QR Code com seu WhatsApp para conectar a instância.",
          })
        } else {
          // If no QR code, assume it's already connected or connecting
          onUpdate(instance.name, { status: "connected", qrCode: null })
          toast({
            title: "Instância Conectada",
            description: `Instância "${instance.name}" conectada com sucesso.`,
          })
        }
      } else {
        throw new Error(data.message || "Erro ao conectar instância.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Conectar Instância",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      })
      onUpdate(instance.name, { status: "disconnected", qrCode: null })
    } finally {
      setLoadingAction(null)
    }
  }

  const handleLogout = async () => {
    setLoadingAction("logout")
    try {
      const response = await fetch(`/api/evolution/instance/logout/${instance.name}`, {
        method: "DELETE",
        headers: {
          apikey: instance.apiKey,
        },
      })
      const data = await response.json()

      if (response.ok) {
        onUpdate(instance.name, { status: "disconnected", qrCode: null })
        toast({
          title: "Instância Desconectada",
          description: `Instância "${instance.name}" desconectada com sucesso.`,
        })
      } else {
        throw new Error(data.message || "Erro ao desconectar instância.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Desconectar Instância",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      })
    } finally {
      setLoadingAction(null)
    }
  }

  const handleDelete = async () => {
    setLoadingAction("delete")
    try {
      const response = await fetch(`/api/evolution/instance/delete/${instance.name}`, {
        method: "DELETE",
        headers: {
          // Global API key is used for deleting instances
          apikey: process.env.NEXT_PUBLIC_EVOLUTION_API_GLOBAL_API_KEY,
        },
      })
      const data = await response.json()

      if (response.ok) {
        onDelete(instance.name)
        toast({
          title: "Instância Deletada",
          description: `Instância "${instance.name}" deletada com sucesso.`,
        })
      } else {
        throw new Error(data.message || "Erro ao deletar instância.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Deletar Instância",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      })
    } finally {
      setLoadingAction(null)
    }
  }

  const getStatusIcon = () => {
    switch (instance.status) {
      case "connected":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />
      case "disconnected":
        return <XCircle className="h-5 w-5 text-red-500" />
      case "qr_code":
        return <QrCode className="h-5 w-5 text-blue-500" />
      case "loading":
        return <Loader2 className="h-5 w-5 animate-spin text-gray-500" />
      default:
        return null
    }
  }

  const getStatusText = () => {
    switch (instance.status) {
      case "connected":
        return "Conectado"
      case "disconnected":
        return "Desconectado"
      case "qr_code":
        return "Aguardando QR Code"
      case "loading":
        return "Carregando..."
      default:
        return "Desconhecido"
    }
  }

  return (
    <Card className="w-full max-w-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          {instance.name}
        </CardTitle>
        <CardDescription>{getStatusText()}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center min-h-[150px]">
        {instance.status === "qr_code" && instance.qrCode && (
          <div className="flex flex-col items-center gap-2">
            <Image src={`data:image/png;base64,${instance.qrCode}`} alt="QR Code" width={150} height={150} />
            <p className="text-sm text-muted-foreground">Escaneie para conectar</p>
          </div>
        )}
        {instance.status === "loading" && (
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Verificando status...</p>
          </div>
        )}
        {instance.status === "disconnected" && !instance.qrCode && (
          <p className="text-sm text-muted-foreground">Instância desconectada. Conecte para usar.</p>
        )}
        {instance.status === "connected" && (
          <p className="text-sm text-muted-foreground">Pronto para enviar mensagens!</p>
        )}
      </CardContent>
      <CardFooter className="flex justify-between gap-2">
        {instance.status === "disconnected" || instance.status === "qr_code" ? (
          <Button onClick={handleConnect} disabled={loadingAction === "connect"} className="flex-1">
            {loadingAction === "connect" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Plug className="mr-2 h-4 w-4" />
            )}
            {loadingAction === "connect" ? "Conectando..." : "Conectar"}
          </Button>
        ) : (
          <Button
            onClick={handleLogout}
            disabled={loadingAction === "logout"}
            variant="outline"
            className="flex-1 bg-transparent"
          >
            {loadingAction === "logout" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <LogOut className="mr-2 h-4 w-4" />
            )}
            {loadingAction === "logout" ? "Desconectando..." : "Desconectar"}
          </Button>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon" disabled={instance.status !== "connected"}>
              <MessageSquare className="h-4 w-4" />
              <span className="sr-only">Ações</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setIsSendMessageDialogOpen(true)}>
              <MessageSquare className="mr-2 h-4 w-4" /> Enviar Mensagem
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setIsContactsListDialogOpen(true)}>
              <Users className="mr-2 h-4 w-4" /> Ver Contatos
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <Button onClick={handleDelete} disabled={loadingAction === "delete"} variant="destructive" size="icon">
          {loadingAction === "delete" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
          <span className="sr-only">Deletar Instância</span>
        </Button>

        <SendMessageDialog
          isOpen={isSendMessageDialogOpen}
          onClose={() => setIsSendMessageDialogOpen(false)}
          instanceName={instance.name}
          instanceApiKey={instance.apiKey}
        />
        <ContactsListDialog
          isOpen={isContactsListDialogOpen}
          onClose={() => setIsContactsListDialogOpen(false)}
          instanceName={instance.name}
          instanceApiKey={instance.apiKey}
        />
      </CardFooter>
    </Card>
  )
}
