"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

interface CreateInstanceDialogProps {
  isOpen: boolean
  onClose: () => void
  onCreateSuccess: (instance: any) => void
}

export function CreateInstanceDialog({ isOpen, onClose, onCreateSuccess }: CreateInstanceDialogProps) {
  const [instanceName, setInstanceName] = useState("")
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handleCreateInstance = async () => {
    if (!instanceName) {
      toast({
        title: "Nome da Instância Necessário",
        description: "Por favor, insira um nome para a instância.",
        variant: "destructive",
      })
      return
    }

    setLoading(true)
    setQrCode(null)
    try {
      const response = await fetch("/api/evolution/instance/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ instanceName, qrcode: true }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Instância Criada!",
          description: `Instância "${instanceName}" criada com sucesso.`,
        })
        if (data.qrcode?.base64) {
          setQrCode(data.qrcode.base64)
        }
        onCreateSuccess({
          name: instanceName,
          apiKey: data.hash,
          status: "disconnected",
          qrcode: data.qrcode?.base64 || null,
        })
      } else {
        throw new Error(data.message || "Erro ao criar instância.")
      }
    } catch (error: any) {
      toast({
        title: "Erro ao Criar Instância",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setInstanceName("")
    setQrCode(null)
    setLoading(false)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Criar Nova Instância</DialogTitle>
          <DialogDescription>Insira um nome para sua nova instância do WhatsApp.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="instanceName" className="text-right">
              Nome
            </Label>
            <Input
              id="instanceName"
              value={instanceName}
              onChange={(e) => setInstanceName(e.target.value)}
              className="col-span-3"
              disabled={loading || !!qrCode}
            />
          </div>
          {qrCode && (
            <div className="flex flex-col items-center gap-2 mt-4">
              <p className="text-sm text-muted-foreground">Escaneie o QR Code com seu WhatsApp:</p>
              <Image src={`data:image/png;base64,${qrCode}`} alt="QR Code" width={200} height={200} />
              <p className="text-xs text-muted-foreground">Aguardando conexão...</p>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={loading}>
            Cancelar
          </Button>
          <Button onClick={handleCreateInstance} disabled={loading || !!qrCode}>
            {loading ? "Criando..." : "Criar Instância"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
