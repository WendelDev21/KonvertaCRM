-- AlterTable
ALTER TABLE "Contact" ADD COLUMN "value" FLOAT DEFAULT 0;
